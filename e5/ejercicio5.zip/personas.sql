-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema tarea2
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema tarea2
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ejercicio5` DEFAULT CHARACTER SET utf8 ;
USE `ejercicio5` ;



CREATE TABLE Estudents (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL
);

INSERT INTO Estudents (firstname, lastname) VALUES ('Julio', 'Albornoz');
INSERT INTO Estudents (firstname, lastname) VALUES ('Sergio', 'Alvarez');
INSERT INTO Estudents (firstname, lastname) VALUES ('Eduardo', 'Barría');
INSERT INTO Estudents (firstname, lastname) VALUES ('Marcelo', 'Becerra');
INSERT INTO Estudents (firstname, lastname) VALUES ('Adele', 'Bourgeix');
INSERT INTO Estudents (firstname, lastname) VALUES ('Daniel', 'Bravo');
INSERT INTO Estudents (firstname, lastname) VALUES ('Felipe', 'Canales');
INSERT INTO Estudents (firstname, lastname) VALUES ('Joaquín', 'Díaz');
INSERT INTO Estudents (firstname, lastname) VALUES ('Rodrigo', 'Fuentes');
INSERT INTO Estudents (firstname, lastname) VALUES ('Vanessa', 'Gaete');
INSERT INTO Estudents (firstname, lastname) VALUES ('José', 'Giralt');
INSERT INTO Estudents (firstname, lastname) VALUES ('Nicolás', 'Jimenez');
INSERT INTO Estudents (firstname, lastname) VALUES ('Emilio', 'Lizama');
INSERT INTO Estudents (firstname, lastname) VALUES ('Guillermo', 'Martinez');

INSERT INTO Estudents (firstname, lastname) VALUES ('Cristóbal', 'Mesías');
INSERT INTO Estudents (firstname, lastname) VALUES ('José', 'Musso');
INSERT INTO Estudents (firstname, lastname) VALUES ('Joshua', 'Nuñez');
INSERT INTO Estudents (firstname, lastname) VALUES ('Matias', 'Orellana');
INSERT INTO Estudents (firstname, lastname) VALUES ('Valentina', 'Ramos');
INSERT INTO Estudents (firstname, lastname) VALUES ('Felipe', 'Raquil');
INSERT INTO Estudents (firstname, lastname) VALUES ('José', 'Romero');
INSERT INTO Estudents (firstname, lastname) VALUES ('Matías', 'Soto');
INSERT INTO Estudents (firstname, lastname) VALUES ('Jorge', 'Toloza');
INSERT INTO Estudents (firstname, lastname) VALUES ('María', 'Ugarte');
INSERT INTO Estudents (firstname, lastname) VALUES ('Sebastián', 'Zapata');
INSERT INTO Estudents (firstname, lastname) VALUES ('Franco', 'Zautzik');
