<?php
require_once('db_config.php');



$db = DbConfig::getConnection();
$sql = "SELECT firstname, lastname FROM estudents";
$result = $db->query($sql);
$res = array();
while ($row = $result->fetch_assoc()) {
	$res[] = $row;
}
$db->close();

foreach($res as $nombre){
	echo $nombre["firstname"] . " " . $nombre["lastname"] . "<br>";
}


?>
