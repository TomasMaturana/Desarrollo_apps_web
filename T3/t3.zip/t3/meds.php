<?php
require_once('modelcontroller/db_config.php');
require_once('modelcontroller/consultas.php');
$db = DbConfig::getConnection();
$medicos = getMedicos($db);
$db->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="static/style.css">
	<script src="static/ajaxs.js"></script>
    <title>Médicos</title>
</head>
<body>
<ul class="navbar">
  <li><a href="index.php">Página principal</a>
  <li><a href="new_med.php">Agregar médico</a>
  <li><a href="meds.php">Ver médicos</a>
  <li><a href="new_hour.php">Publicar atención</a>
  <li><a href="hours.php">Ver atenciones</a>
</ul>

<h1>Médicos disponibles</h1>
<p> </p>

<div>
	<input type="text" id="buscar_medico" name="buscar_medico" size="30" placeholder="Buscar médico" onkeyup="getMedsNames(this.value)">
	<div id="busqueda_medicos" style="position:absolute; background-color:white; display:none;">
	</div>
</div>

<div>
<?php 
$stop=0;
if(isset($_GET['pagina'])){
	if(($_GET['pagina']>=0) && ($_GET['pagina']<(count($medicos)/5) )){
		$pagina=$_GET['pagina']; 
	}
	else{
		$pagina=0;
	}
}
else{
	$pagina=0;
}?>


<table>
	<tr>
	<th>Nombre médico</th>
	<th>Especialidades</th>
	<th>Comuna</th>
	<th>Datos contacto</th>
	</tr>

	<?php 
	$db = DbConfig::getConnection();
	for ($i = 0; $i <5; $i++){
		if(count($medicos)>(5*$pagina+$i)){
			$medico=$medicos[5*$pagina+$i];
			$especialidades=getEspecialidadMed($db, $medico['id']);?>
			<tr onClick="mostrarMedsModal('<?php echo $medico['id'];?>', 1)">
				<td><a href="#"><?php echo $medico['nombre']; ?> </a></td>
				<td><?php foreach ($especialidades as $especialidad) { 
					echo getEspecialidad($especialidad['especialidad_id'], $db); ?> <br> <?php 
				}?> </td>
				<td><?php echo getComuna($medico['comuna_id'], $db); ?> </td>
				<td><?php echo $medico['email']; ?> 
					<br>Twitter:<?php echo $medico['twitter']; ?> 
					<br>Fono:<?php echo $medico['celular']; ?> </td>
			</tr>
	<?php if(count($medicos)-1==(5*$pagina+$i)){
		$stop=-1;
	}}
		else{
			$stop=-1;
		}
	} 
	$db->close();?>
</table>






<?php if($pagina>0){?>
<a type="button" id="next_page" style="width: 18%; padding: 3px 20px; margin: 5px 0;" href="meds.php?pagina=<?php echo $pagina-1 ?>">Página anterior</a> <br> <?php } ?>
<?php if($stop==0){?>
<a type="button" id="next_page" style="width: 18%; padding: 3px 20px; margin: 5px 0;" href="meds.php?pagina=<?php echo $pagina+1 ?>">Siguiente página</a> <?php } ?>

</div>

<div id="modal"></div>




</body>
</html>

