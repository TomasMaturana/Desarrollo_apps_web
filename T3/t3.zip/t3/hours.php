<?php
require_once('modelcontroller/db_config.php');
require_once('modelcontroller/consultas.php');
$db = DbConfig::getConnection();
$atenciones = getAtenciones($db);
$db->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="static/style.css">
	<script src="static/ajaxs.js"></script>
    <title>Ver atenciones</title>
</head>
<body>
<ul class="navbar">
  <li><a href="index.php">Página principal</a>
  <li><a href="new_med.php">Agregar médico</a>
  <li><a href="meds.php">Ver médicos</a>
  <li><a href="new_hour.php">Publicar atención</a>
  <li><a href="hours.php">Ver atenciones</a>
</ul>

<h1>Atenciones solicitadas</h1>
<p> </p>

<div>
	<input type="text" id="buscar_atencion" name="buscar_atencion" size="30" placeholder="Buscar atención" onkeyup="getAtencionNames(this.value)">
	<div id="busqueda_atencion" style="position:absolute; background-color:white; display:none;">
	</div>
</div>

<?php 
$stop=0;
if(isset($_GET['pagina'])){
	if(($_GET['pagina']>=0) && ($_GET['pagina']<(count($atenciones)/5) )){
		$pagina=$_GET['pagina']; 
	}
	else{
		$pagina=0;
	}
}
else{
	$pagina=0;
}?>

<table>
  <tr>
    <th>Nombre solicitante</th>
    <th>Especialidad</th>
    <th>Comuna</th>
	<th>Datos contacto</th>
  </tr>

<?php 
$db = DbConfig::getConnection();
for ($i = 0; $i <5; $i++){
	if(count($atenciones)>(5*$pagina+$i)){
		$atencion=$atenciones[5*$pagina+$i];?>
		<tr onClick="mostrarModal('<?php echo $atencion['id'];?>', 1)"> 
			<td><a href="#"><?php echo $atencion['nombre_solicitante']; ?> </a></td>
			<td><?php echo getEspecialidad($atencion['especialidad_id'], $db); ?> </td>
			<td><?php echo getComuna($atencion['comuna_id'], $db); ?> </td>
			<td><?php echo $atencion['email']; ?> 
				<br>Twitter:<?php echo $atencion['twitter']; ?> 
				<br>Fono:<?php echo $atencion['celular']; ?> </td>
		</tr>
<?php if(count($atenciones)-1==(5*$pagina+$i)){
	$stop=-1;
}}
	else{
		$stop=-1;
	}
} 
$db->close();?>

</table>




<?php if($pagina>0){?>
<a type="button" id="previous_page" style="width: 18%; padding: 3px 20px; margin: 5px 0;" href="hours.php?pagina=<?php echo $pagina-1 ?>">Página anterior</a> <br> <?php } ?>
<?php if($stop==0){?>
<a type="button" id="next_page" style="width: 18%; padding: 3px 20px; margin: 5px 0;" href="hours.php?pagina=<?php echo $pagina+1 ?>">Siguiente página</a> <?php } ?>


<div id="modal"></div>

</body>
</html>

