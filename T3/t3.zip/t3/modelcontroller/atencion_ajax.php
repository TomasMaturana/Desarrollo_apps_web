<?php
require_once('db_config.php');
$db = DbConfig::getConnection();
$sql = "SELECT id, nombre_solicitante FROM solicitud_atencion WHERE nombre_solicitante LIKE '%".$_GET["q"]."%'";
$result = $db->query($sql);
$res = array();
while ($row = $result->fetch_assoc()) {
	$res[] = $row;
}
$db->close();
$count=0;
$busquedaDiv='"busqueda_atencion"';
foreach($res as $nombre){
	echo "<a href='#' onClick='mostrarModal(".$nombre['id'].", 1, ".$busquedaDiv.")'>".$nombre['nombre_solicitante']."</a> <br>";
	$count++;
}

if($count==0){
	echo "No hay resultados para su búsqueda";
}

?>