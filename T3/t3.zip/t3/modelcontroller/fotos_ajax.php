<?php
require_once('db_config.php');
require_once('consultas.php');
$db = DbConfig::getConnection();
$sql = "SELECT DISTINCT medico.id, nombre, comuna_id, twitter,email FROM medico JOIN foto_medico ON medico.id = foto_medico.medico_id";
$result = $db->query($sql);
$res = array();
while ($row = $result->fetch_assoc()) {
	$res[] = $row;
}

$sql2 = "SELECT DISTINCT medico.id, comuna_id, count(comuna_id) FROM medico JOIN foto_medico ON medico.id = foto_medico.medico_id GROUP BY comuna_id";
$result2 = $db->query($sql);
$res2 = array();
while ($row = $result2->fetch_assoc()) {
	$res2[] = $row;
}

$com=array();
foreach($res2 as $comuna2){
	$meds=array();
	foreach($res as $comuna){
		if($comuna["comuna_id"]==$comuna2["comuna_id"]){
			$especialidades=array();
			foreach(getEspecialidadMed($db, $comuna["id"]) as $especialidad){
				$especialidades[]=getEspecialidad($especialidad['especialidad_id'], $db);
			}
			$meds[]= [$comuna["id"],$comuna["nombre"],$comuna["twitter"],$comuna["email"], $especialidades];
		}
	}
	$com[]= [$comuna2["id"], getComuna($comuna2["comuna_id"],$db), $meds];
}
$json = json_encode($com);
echo $json;

$db->close();
?>