<?php
require_once('db_config.php');
$db = DbConfig::getConnection();
$sql = "SELECT id, nombre FROM medico WHERE nombre LIKE '%".$_GET["q"]."%'";
$result = $db->query($sql);
$res = array();
while ($row = $result->fetch_assoc()) {
	$res[] = $row;
}
$db->close();
$count=0;
$busquedaDiv='"busqueda_medicos"';
foreach($res as $nombre){
	echo "<a href='#' onClick='mostrarMedsModal(".$nombre['id'].", 1, ".$busquedaDiv.")'>".$nombre['nombre']."</a> <br>";
	$count++;
}

if($count==0){
	echo "No hay resultados para su búsqueda";
}

?>