<?php
/**
 * Validación nombre con PHP.
 */

function checkRegion($post){
	if(isset($post['region-solicitante'])){
		return true;
	}
	return false;
}

function checkComuna($post){
	if(isset($post['comuna-solicitante'])){
		return true;
	}
	return false;
}

function checkNombre($post){
	if(isset($post['nombre-solicitante'])){
		$regexp = "/^[A-Za-záéíóú\ ]+$/";
		if(preg_match($regexp, $post['nombre-solicitante']) && strlen($post['nombre-solicitante'])<= 30){
			return true;
		}
	}
	return false;
}

function checkSintomas($post){
	if(isset($post['sintomas-solicitante'])){
		$regexp = "/^[A-Za-záéíóú\ ]+|$/";
		if(preg_match($regexp, $post['sintomas-solicitante']) && strlen($post['sintomas-solicitante'])<= 500){
			return true;
		}
	}
	else {
		return true;
	}
	return false;
}

function checkEspecialidad($post){
	if(isset($post['especialidad-solicitante']) && count($post['especialidad-solicitante']) == 1){
		return true;
	}
	return false;
}

function checkTwitter($post){
	if(isset($post['twitter-solicitante'])){
		$regexp = "/^@?[a-zA-Z0-9_]{1,15}|$/";
		if(preg_match($regexp, $post['twitter-solicitante'])){
			return true;
		}
	}
	return false;
}

function checkEmail($post){
	if(isset($post['email-solicitante'])){
		$regexp = "/^[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/";
		if(preg_match($regexp, $post['email-solicitante'])){
			return true;
		}
	}
	return false;
}

function checkTelefono($post){
	if(isset($post['celular-solicitante'])){
		$regexp = "/^[0-9]{9}|$/";
		if(preg_match($regexp, $post['celular-solicitante'])){
			return true;
		}
	}
	return false;
}
?>