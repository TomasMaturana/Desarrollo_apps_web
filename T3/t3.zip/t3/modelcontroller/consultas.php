<?php
/*
Implementar:
1. Preparar SQL para insertar orden: INSERT INTO ordenes (nombre, direccion, comuna, masa, comentario) VALUES ('%s', '%d', '%s', %d, %d, '%s')". Usar sprintf y limpiar los campos con la función limpiar(texto);
2. Ejecutar SQL
3. Recuperar el id de la inserción anterior
4. Preparar SQL para insertar los ingredientes: INSERT INTO ordenes_ingredientes (id_orden, id_ingrediente) VALUES (%d, %d).
x6. retornar true si todo salió bien, false si surgió un problema.
*/
function saveOrder($db, $nombre, $telefono, $direccion, $comuna, $masa, $ingredientes, $comentarios,$costo){
	$stmt = $db->prepare("INSERT INTO ordenes (nombre, telefono, direccion, comuna, masa, comentarios,costo) VALUES (?, ?, ?, ?, ?, ?, ?)");
	$stmt->bind_param("sdsddsd", $nombre_bd, $telefono_bd, $direccion_bd, $comuna_bd, $masa_bd, $comentarios_bd, $costo_bd);
	$nombre_bd=limpiar($db,$nombre);
	$telefono_bd=limpiar($db, $telefono);
	$direccion_bd=limpiar($db,$direccion);
	$comuna_bd=limpiar($db,$comuna);
	$masa_bd=limpiar($db,$masa);
	$comentarios_bd=limpiar($db,$comentarios);
	$costo_bd=limpiar($db,$costo);
	if ($stmt->execute()) {
		$last_id = $db->insert_id;
		$stmt_ing=$db->prepare("INSERT INTO ordenes_ingredientes (orden_id, ingrediente_id) VALUES (?,?)");
		$stmt_ing->bind_param("dd",$id_orden_bd,$id_ing_bd);
		$id_orden_bd=$last_id;
		foreach ($ingredientes as $key => $value) {
			$id_ing_bd=$key;
			$stmt_ing->execute();
		}
		return true;
	}
	return false;
}

function getOrders($db){
	$sql = "SELECT ordenes.id, ordenes.nombre, ordenes.direccion, comunas.nombre as comuna_nombre, ordenes.masa
	FROM ordenes, comunas
	WHERE ordenes.comuna = comunas.id";
	$result = $db->query($sql);
	$res = array();
	while ($row = $result->fetch_assoc()) {
		$res[] = $row;
	}
	return $res;
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function guardarMedico($db, $comuna, $nombre, $experiencia, $especialidad, $twitter, $email, $telefono, $files){
	$stmt = $db->prepare("INSERT INTO medico (nombre, experiencia, comuna_id, twitter, email, celular) VALUES (?, ?, ?, ?, ?, ?)");
	$stmt->bind_param("ssdsss", $nombre_bd, $experiencia_bd, $comuna_bd, $twitter_bd, $email_bd, $telefono_bd);
	$nombre_bd=limpiar($db,$nombre);
	$experiencia_bd=limpiar($db, $experiencia);
	$twitter_bd=limpiar($db,$twitter);
	$email_bd=limpiar($db,$email);
	$telefono_bd=limpiar($db,$telefono);
	$comuna_bd=$comuna;
	
	if ($stmt->execute()) {
		$last_id = $db->insert_id;
		$stmt_especialidad=$db->prepare("INSERT INTO especialidad_medico (medico_id, especialidad_id) VALUES (?,?)");
		$stmt_especialidad->bind_param("dd",$medico_id_bd,$especialidad_id_bd);
		$medico_id_bd=$last_id;
		foreach ($especialidad as $key) {
			$especialidad_id_bd=$key;
			$stmt_especialidad->execute();
		}
		
		$stmt_archivo=$db->prepare("INSERT INTO foto_medico (ruta_archivo, nombre_archivo, medico_id) VALUES (?,?,?)");
		$stmt_archivo->bind_param("ssd", $target_file_bd, $file_name_bd, $medico_id_bd);
		$medico_id_bd = $last_id;
		foreach ($files as $key){
			$target_file_bd = $key["file"];
			$file_name_bd = limpiar($db,$key["name"]);
			$stmt_archivo->execute();
		}
		return true;
	}
	return false;
}



function guardarAtencion($db, $comuna, $nombre, $sintomas, $especialidad, $twitter, $email, $telefono, $files){
	$stmt = $db->prepare("INSERT INTO solicitud_atencion (nombre_solicitante, especialidad_id, sintomas, twitter, email, celular, comuna_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
	$stmt->bind_param("sdssssd", $nombre_bd, $especialidad_bd, $sintomas_bd, $twitter_bd, $email_bd, $telefono_bd, $comuna_bd);
	$nombre_bd=limpiar($db,$nombre);
	$especialidad_bd=$especialidad;
	$sintomas_bd=limpiar($db, $sintomas);
	$twitter_bd=limpiar($db,$twitter);
	$email_bd=limpiar($db,$email);
	$telefono_bd=limpiar($db,$telefono);
	$comuna_bd=$comuna;
	
	if ($stmt->execute()) {
		$last_id = $db->insert_id;		
		$stmt_archivo=$db->prepare("INSERT INTO archivo_solicitud (ruta_archivo, nombre_archivo, mimetype, solicitud_atencion_id) VALUES (?,?,?,?)");
		$stmt_archivo->bind_param("sssd", $target_file_bd, $file_name_bd, $mimetype_bd, $solicitud_atencion_id);
		$solicitud_atencion_id = $last_id;
		foreach ($files as $key){
			$target_file_bd = $key["file"];
			$file_name_bd = limpiar($db,$key["name"]);
			$mimetype_bd = $key["mimetype"];
			$stmt_archivo->execute();
		}
		return true;
	}
	return false;
}


function limpiar($db, $str){
	return htmlspecialchars($db->real_escape_string($str));
}

function getComunas($db){
	$sql = "SELECT id, nombre FROM comuna";
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res;
}

function getRegiones($db){
	$sql = "SELECT id, nombre FROM region";
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res;
}

/*
Recibe un id y retorna el nombre de la comuna.
*/
function getComuna($id, $db){
	$sql = "SELECT nombre FROM comuna WHERE id =". $id;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res[0]['nombre'];
}

/*
Recibe un id y retorna el nombre de la región.
*/
function getRegion($id, $db){
	$sql = "SELECT region.nombre FROM region JOIN comuna ON region.id = comuna.region_id WHERE comuna.id=". $id;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res[0]['nombre'];
}

/*
Recibe un id y retorna el nombre de la especialidad.
*/
function getEspecialidad($id, $db){
	$sql = "SELECT descripcion FROM especialidad WHERE id =". $id;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res[0]['descripcion'];
}


/*
Recibe una comuna y retorna el id de la comuna y su nombre.
*/
function getIdComuna($name, $db){
	$sql = "SELECT id, nombre FROM comuna WHERE nombre LIKE '%". $name ."%'" ;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res[0];
}


/*
Retorna un arreglo con los médicos presentes en la base de datos.
*/
function getMedicos($db){
	$sql = "SELECT * FROM medico" ;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res;
}

/*
Retorna un arreglo con los médicos presentes en la base de datos.
*/
function getMedico($id, $db){
	$sql = "SELECT * FROM medico WHERE id=". $id;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res[0];
}

/*
Retorna un arreglo con las especialidades del médico con id=$id.
*/
function getEspecialidadMed($db, $id){
	$sql = "SELECT * FROM especialidad_medico WHERE medico_id =". $id;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res;
}

/*
Retorna un arreglo con las fotos del médico con id=$id.
*/
function getFotosMed($db, $id){
	$sql = "SELECT * FROM foto_medico WHERE medico_id =". $id;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res;
}


/*
Retorna un arreglo con las atenciones presentes en la base de datos.
*/
function getAtenciones($db){
	$sql = "SELECT * FROM solicitud_atencion" ;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res;
}

/*
Retorna un arreglo con la atencion con identificador= id.
*/
function getAtencion($id,$db){
	$sql = "SELECT * FROM solicitud_atencion WHERE id=". $id;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res[0];
}

/*
Retorna un arreglo con las fotos del médico con id=$id.
*/
function getDocsAtencion($db, $id){
	$sql = "SELECT * FROM archivo_solicitud WHERE solicitud_atencion_id =". $id;
		$result = $db->query($sql);
		$res = array();
		while ($row = $result->fetch_assoc()) {
			$res[] = $row;
		}
	return $res;
}
?>
