<?php 
require_once('db_config.php');
require_once('consultas.php');
$db = DbConfig::getConnection();
$comilla="'";
$atencion = getAtencion($_GET["id"],$db);

echo '<div id="atencionModal" class="modal">';
	echo '<div class="modal-contenido">';
		echo '<span onClick="mostrarModal('.$comilla.'atencionModal'.$comilla.', 0)" class="close">Cerrar</span>';
		echo '<h2>'.$atencion['nombre_solicitante'].'</h2>';
		echo '<p><b>Región de atención:</b>'.getRegion($atencion['comuna_id'], $db).'</p>';
		echo '<p><b>Comuna de atención</b>'.getComuna($atencion['comuna_id'], $db).'</p>';
		echo '<p><b>Síntomas:</b>'.$atencion['sintomas'].'</p>';
		echo '<p><b>Especialidad:</b>'. getEspecialidad($atencion['especialidad_id'], $db).'</p>';
		echo '<p><b>Twitter:</b>'.$atencion['twitter'].'</p>';
		echo '<p><b>Email:</b>'.$atencion['email'].'</p>';
		echo '<p><b>Celular:</b>'.$atencion['celular'].'</p>';
		$docs = getDocsAtencion($db, $atencion['id']);
		foreach ($docs as $doc){
			echo '<p> <a href="'.substr($doc['ruta_archivo'], 3).'">Descargar '. $doc['nombre_archivo'].'. </a>Archivo del tipo '.$doc['mimetype'].'</p> <br>';
		}
	echo '</div>';
echo '</div>';

$db->close();
?>

