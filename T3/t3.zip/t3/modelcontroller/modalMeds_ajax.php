<?php 
require_once('db_config.php');
require_once('consultas.php');
$db = DbConfig::getConnection();
$comilla="'";
$medico = getMedico($_GET["id"],$db);
$especialidades=getEspecialidadMed($db, $medico['id']);
echo '<div id="medicoModal" class="modal">';
	echo '<div class="modal-contenido">';
		echo '<span onClick="mostrarMedsModal('.$comilla.'medicoModal'.$comilla.', 0)" class="close">Cerrar</span>';
		echo '<h2>'.$medico['nombre'].'</h2>';
		echo '<p><b>Región de atención:</b>'.getRegion($medico['comuna_id'], $db).'</p>';
		echo '<p><b>Comuna de atención</b>'.getComuna($medico['comuna_id'], $db).'</p>';
		echo '<p><b>Experiencia:</b>'.$medico['experiencia'].'</p>';
		echo '<p><b>Especialidades:</b>';
		foreach ($especialidades as $especialidad) { 
			echo getEspecialidad($especialidad['especialidad_id'], $db).'<br>';
		}
		echo '</p>';
		echo '<p><b>Twitter:</b>'.$medico['twitter'].'</p>';
		echo '<p><b>Email:</b>'.$medico['email'].'</p>';
		echo '<p><b>Celular:</b>'.$medico['celular'].'</p>';
		$fotos = getFotosMed($db, $medico['id']);
		foreach ($fotos as $foto) {
			echo '<img src="'.substr($foto['ruta_archivo'], 3).'" alt="'.$medico['nombre'].'" height="320" width="240" onClick="this.style.height = '.$comilla.'600px'.$comilla.'; this.style.width = '.$comilla.'800px'.$comilla.';"> ';
		}
	echo '</div>';
echo '</div>';

$db->close();
?>