<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="static/style.css">
	<script src="static/jquery-3.5.0.js" ></script>
	<!-- Validator -->
	<script src="static/validator.js"></script>
	<!-- /Validator -->
	<!-- /Fotos -->
	<script src="static/photoCharger.js"></script>
	<!-- /Fotos -->
	<!-- relleno región y comuna -->
	<script src="static/regionesYComunas.js"></script>
	<!-- relleno región y comuna -->
    <title>Agregar médico</title>
</head>
<body>
<ul class="navbar">
  <li><a href="index.php">Página principal</a>
  <li><a href="new_med.php">Agregar médico</a>
  <li><a href="meds.php">Ver médicos</a>
  <li><a href="new_hour.php">Publicar atención</a>
  <li><a href="hours.php">Ver atenciones</a>
</ul>

<h1>Agregar médico:</h1>
<p> Los campos marcados con * son obligatorios</p>

<div class="avisos">
  <?php
    if(isset($_GET['errores'])){
      echo $_GET['errores']; 
    }
  ?>
</div>

<div>
  <form method="post" id="form1" action="modelcontroller/agregar_medico.php" enctype="multipart/form-data">
    <br>
	
	<div id="divregion-medico">
		<label for="region-medico" class="text-field">Región*</label>
		<br>
		<select id="region-medico" name="region-medico" required onchange="validate('region-medico', 'select')">
			<option value="">Seleccione región</option>
		</select>
    </div>
	
	<div id="divcomuna-medico">
		<label for="comuna-medico" class="text-field">Comuna*</label>
		<br>
		<select id="comuna-medico" name="comuna-medico" required onchange="validate('comuna-medico', 'select')">
			<option value="">Seleccione comuna</option>
		</select>
    </div>
	
	<div id="divnombre-medico">	
		<label for="nombre-medico" class="text-field">Nombre de médico*</label>
		<br>
		<input type="text" id="nombre-medico" name="nombre-medico" size="30" placeholder="Nombre de Médico" required onchange="validate('nombre-medico', 'text',1,30)">
    </div>
	
	<div id="divexperiencia-medico">	
		<label for="experiencia-medico" class="text-field">Experiencia</label>
		<br>
		<textarea id="experiencia-medico" name="experiencia-medico" maxlength="500" cols="40" rows="8" placeholder="Experiencia" onchange="validate('experiencia-medico', 'len', 1, 500)"></textarea>
    </div>
	
	<div id="divespecialidades-medico" >	
		<label  class="text-field">Especialidades*</label>
		<div class="parent" id="especialidades-medico" onchange="validate('especialidades-medico', 'check',1,5)">
			<div class="child">	
				<input type="checkbox" name="especialidades-medico[]" value="1">Cardiología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="2">Gastroenterología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="3">Endocrinología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="4">Epidemiología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="25">Geriatría
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="5">Hematología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="6">Infectología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="7">Medicina del deporte
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="8">Medicina de urgencias
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="9">Medicina interna
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="10">Nefrología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="11">Neumología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="12">Neurología
			</div>
			<div class="child">
				<input type="checkbox" name="especialidades-medico[]" value="13">Nutriología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="14">Oncología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="15">Pediatría
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="16">Psiquiatría
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="17">Reumatología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="18">Toxicología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="19">Dermatología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="20">Ginecología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="21">Oftalmología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="22">Otorrinolaringología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="23">Urología
				<br>
				<input type="checkbox" name="especialidades-medico[]" value="24">Traumatología
				<br>
			</div>
		</div>
	</div>
	
	<div id="divfoto-medico">
		<div id="foto-medico" onchange="validate('foto-medico', 'file')">
			<p class="text-field">Foto médico*</p>
			<br>
			<div id="photo1">
				<input type="hidden" name="MAX_FILE_SIZE" value="3000000" />
				<input type="file" name="foto-medico[]" accept="image/jpeg,image/jpg,image/png" required>
				<br>
			</div>
			<button type="button" id="new_photo_button" style="width: 18%; padding: 3px 20px; margin: 5px 0;" onclick="new_photo()">Subir otra</button>
			<br>
		</div>
	</div>
	
	<div id="divtwitter-medico">	
		<label for="twitter-medico" class="text-field">Twitter contacto</label>
		<br>
		<input type="text" id="twitter-medico" name="twitter-medico" size="30" placeholder="Twitter contacto" onchange="validate('twitter-medico', 'twitter',0)">
    </div>
	
	<div id="divemail-medico">
		<label for="email-medico" class="text-field">Email contacto</label>
		<br>
		<input type="text" id="email-medico" name="email-medico" size="30" placeholder="Email contacto" onchange="validate('email-medico', 'email',0)">
    </div>
	
	<div id="divcelular-medico">	
		<label for="celular-medico" class="text-field">Número celular contacto</label>
		<br>
		<input type="text" id="celular-medico" name="celular-medico" pattern="[0-9]{9}" placeholder="9 9999 9999" onchange="validate('celular-medico', 'phone',0)">
    </div>
	
	<div>	
		<input type="submit" id="submit-form1" disabled value="Agregar">
		<br>
		<button type="reset" >Limpiar</button>
	</div>
	
  </form>
</div>
<script>
$(document).ready(regiones('region-medico','comuna-medico'));
</script>

</body>
</html>
