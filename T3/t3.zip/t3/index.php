<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="static/style.css">
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css" integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ==" crossorigin=""/>
	<script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js" integrity="sha512-gZwIG9x3wUXg2hdXF6+rVkLF/0Vi9U8D2Ntg4Ga5I5BZpVkVxlJWbSQtXPSiUTtC0TjtGOmxa1AJPuV0CPthew==" crossorigin=""></script>
	<script src="static/map.js"></script>
	<style>#mapid{height:600px;}</style>
	
    <title>Title</title>
</head>

<body>
<ul class="navbar">
  <li><a href="index.php">Página principal</a>
  <li><a href="new_med.php">Agregar médico</a>
  <li><a href="meds.php">Ver médicos</a>
  <li><a href="new_hour.php">Publicar atención</a>
  <li><a href="hours.php">Ver atenciones</a>
</ul>


<div class="avisos">
  <?php
    if(isset($_GET['avisos'])){
      echo $_GET['avisos']; 
    }
  ?>
</div>

<h1>Página principal</h1>

<div id="mapid"></div>

<script> map();</script>
	

<!-- Firma y fecha -->
<address> 
	Tomás Maturana <br> 
	Otoño 2020 <br> 
	T1 Desarrollo de Aplicaciones Web
</address>

</body>
</html>

