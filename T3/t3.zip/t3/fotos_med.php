<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="static/style.css">
	<script src="static/ajaxs.js"></script>
    <title>Médicos</title>
</head>
<body>
<ul class="navbar">
  <li><a href="index.php">Página principal</a>
  <li><a href="new_med.php">Agregar médico</a>
  <li><a href="meds.php">Ver médicos</a>
  <li><a href="new_hour.php">Publicar atención</a>
  <li><a href="hours.php">Ver atenciones</a>
</ul>

<?php
require_once('modelcontroller/db_config.php');
require_once('modelcontroller/consultas.php');
$comilla="'";
$db = DbConfig::getConnection();
$fotos = getFotosMed($db, $_GET["id"]);
		foreach ($fotos as $foto) {
			echo '<img src="'.substr($foto['ruta_archivo'], 3).'" height="320" width="240" onClick="this.style.height = '.$comilla.'600px'.$comilla.'; this.style.width = '.$comilla.'800px'.$comilla.';"> <br> ';
		}

$db->close();
?>

<a href="javascript: history.go(-1)">Volver</a>

</body>
</html>

