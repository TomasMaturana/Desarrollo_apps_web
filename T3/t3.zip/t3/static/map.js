

function map(){
	var mymap = L.map('mapid').setView([-33.45, -70.66], 12);

	L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
        accessToken: 'pk.eyJ1IjoidG9tc2Rhcm8iLCJhIjoiY2tiaGRuYXg5MDRiZDJ0b2Rndmttdnk1MCJ9.u2isFiZ9J893YeAudJySMg'
    }).addTo(mymap);

	comunas= comunasJson();
	getFotos(mymap, comunas);
	
}

function comunasJson(){
	var data="static/chile.json";
	var xhr= new XMLHttpRequest();
	
	xhr.onreadystatechange= function(){
		if(xhr.readyState==4){
			var json=JSON.parse(xhr.responseText);
			comunas= new Array();
			json.forEach(element =>{
				comunas.push([element.name, element.lat, element.lng]);
			})
			return comunas;
		}
	}
	
	xhr.open("GET",data, false);
	xhr.send();
	return xhr.onreadystatechange();
	
}

function getFotos(map, comunas){
	if (window.XMLHttpRequest) {
		xmlhttp=new XMLHttpRequest();
	} else {
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			var json=JSON.parse(xmlhttp.responseText);
			json.forEach(element => {
				for(j = 0;j<comunas.length;j++){
					if(element[1]==comunas[j][0]){
						console.log(comunas[j][0]);
						var marker= L.marker([comunas[j][1],comunas[j][2]], {title: element[2].length}).addTo(map);
						
						var medicos = '<table style="width: 100%"><thead><tr><th >Nombre</th><th>Especialidades</th><th>Twitter</th><th>Email</th><th>Fotos</th></tr></thead><tbody>';

						for(k = 0; k < element[2].length; k++){
							medicos += "<tr><td>"+element[2][k][1]+"</td>"; //nombre
							medicos += "<td>";
							for(l = 0; l < element[2][k][4].length;l++){//especialidades
								medicos += element[2][k][4][l]+"<br>";
							}
							medicos += "</td>";
							medicos += "<td>"+element[2][k][2]+"</td><td>"+element[2][k][3]+"</td>";
							medicos += "<td><a href='fotos_med.php?id="+element[2][k][0]+"'>Ver fotos</a></td></tr>";
						}
						
						medicos = medicos + "</tbody></table>"

						marker.bindPopup(medicos,{maxWidth:500});
					}
				}
			})
		}
	}
	
	xmlhttp.open("GET", "modelcontroller/fotos_ajax.php", false);
	xmlhttp.send();
}
