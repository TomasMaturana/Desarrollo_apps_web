function getMedsNames(val){
	if(val.length>2){
		if (window.XMLHttpRequest) {
			xmlhttp=new XMLHttpRequest();
		} else {
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function(){
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById("busqueda_medicos").innerHTML = this.responseText;
				document.getElementById("busqueda_medicos").style.display = 'block';
			}
		}
		
		xmlhttp.open("GET", "modelcontroller/meds_ajax.php?q=" + val, true);
		xmlhttp.send();
	}
	else{
		document.getElementById("busqueda_medicos").style.display = 'none';
	}
}

function mostrarMedsModal(modalId, onOff, ocultarExtra=0){
	if(!isNaN(modalId)){
		if (window.XMLHttpRequest) {
			xmlhttp=new XMLHttpRequest();
		} else {
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function(){
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById("modal").innerHTML = this.responseText;
				document.getElementById("medicoModal").style.display = 'block';
			}
		}
		
		xmlhttp.open("GET", "modelcontroller/modalMeds_ajax.php?id=" + modalId, true);
		xmlhttp.send();
	}
	else{
		if(onOff==1){
			document.getElementById(modalId).style.display = 'block';
		} 
		else{
			document.getElementById(modalId).style.display = 'none';
		}
	}
	if(ocultarExtra){
		document.getElementById(ocultarExtra).style.display = 'none';
	}
}

function getAtencionNames(val){
	if(val.length>2){
		if (window.XMLHttpRequest) {
			xmlhttp=new XMLHttpRequest();
		} else {
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function(){
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById("busqueda_atencion").innerHTML = this.responseText;
				document.getElementById("busqueda_atencion").style.display = 'block';
			}
		}
		
		xmlhttp.open("GET", "modelcontroller/atencion_ajax.php?q=" + val, true);
		xmlhttp.send();
	}
	else{
		document.getElementById("busqueda_atencion").style.display = 'none';
	}
}

function mostrarModal(modalId, onOff, ocultarExtra=0){
	if(!isNaN(modalId)){
		if (window.XMLHttpRequest) {
			xmlhttp=new XMLHttpRequest();
		} else {
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function(){
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById("modal").innerHTML = this.responseText;
				document.getElementById("atencionModal").style.display = 'block';
			}
		}
		
		xmlhttp.open("GET", "modelcontroller/modalAtencion_ajax.php?id=" + modalId, true);
		xmlhttp.send();
	}
	else{
		if(onOff==1){
			document.getElementById(modalId).style.display = 'block';
		} 
		else{
			document.getElementById(modalId).style.display = 'none';
		}
	}
	if(ocultarExtra){
		document.getElementById(ocultarExtra).style.display = 'none';
	}
}