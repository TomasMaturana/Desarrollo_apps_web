 /**
  * Funciones para poder cargar fotos en new_med
  */

var DEBUG=1;

function new_file(id, maxFiles, accept, buttonId){
	var files=document.getElementsByName(id+"[]"); 
	if (DEBUG) console.log(files);
	var numFiles= files.length+1;
	var button=document.getElementById(buttonId);
	var comillas="'";
	var htmlPhoto = '<div id="file'+numFiles+'"> <input type="file" name="'+id+'[]" accept="'+accept+'" required> <button type="button" id="delete_file_button'+numFiles+'" style="width: 18%; background-color: red; padding: 3px 20px; margin: 5px 0;" onclick="delete_file('+comillas+id+comillas+')">Eliminar</button><br> </div>';
	if (numFiles <=maxFiles){
		button.insertAdjacentHTML("beforebegin",htmlPhoto);
	}
}

function delete_file(id){
	var files=document.getElementsByName(id+"[]"); 
	var numFiles= files.length;
	if (DEBUG) console.log("deleting");
	var toDelete = document.getElementById("file"+numFiles);
	var parent=toDelete.parentNode;
	parent.removeChild(toDelete);
}

$(document).on('change','input[type="file"]',function(){	
	var fileName = this.files[0].name;
	var fileSize = this.files[0].size;

	if(fileSize > 3000000){
		alert('El archivo no debe superar los 3MB');
		this.value = '';
		this.files[0].name = '';
	}else{
		var ext = fileName.split('.').pop();
		ext = ext.toLowerCase();
    
		// console.log(ext);
		switch (ext) {
			case 'jpg':
			case 'jpeg':
			case 'png':
			case 'avi':
			case 'mp4':
			case 'mov':
			case 'wmv':
			case 'mpeg':
			case 'm4v':
			case 'pdf': break;
			default:
				alert('El archivo no tiene la extensión adecuada');
				this.value = ''; // reset del valor
				this.files[0].name = '';
		}
	}
});