<?php
require_once('modelcontroller/db_config.php');
require_once('modelcontroller/consultas.php');
$db = DbConfig::getConnection();
$atenciones = getAtenciones($db);
$db->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="static/style.css">
    <title>Ver atenciones</title>
</head>
<body>
<ul class="navbar">
  <li><a href="index.php">Página principal</a>
  <li><a href="new_med.php">Agregar médico</a>
  <li><a href="meds.php">Ver médicos</a>
  <li><a href="new_hour.php">Publicar atención</a>
  <li><a href="hours.php">Ver atenciones</a>
</ul>


<h1>Atenciones solicitadas</h1>
<p> </p>

<?php 
$stop=0;
if(isset($_GET['pagina'])){
	if(($_GET['pagina']>=0) && ($_GET['pagina']<(count($atenciones)/5) )){
		$pagina=$_GET['pagina']; 
	}
	else{
		$pagina=0;
	}
}
else{
	$pagina=0;
}?>

<table>
  <tr>
    <th>Nombre solicitante</th>
    <th>Especialidad</th>
    <th>Comuna</th>
	<th>Datos contacto</th>
  </tr>

<?php 
$db = DbConfig::getConnection();
for ($i = 0; $i <5; $i++){
	if(count($atenciones)>(5*$pagina+$i)){
		$atencion=$atenciones[5*$pagina+$i];?>
		<tr onClick="mostrarModal('medicoModal<?php echo $atencion['id'];?>', 1)"> 
			<td><a href="#medicoModal<?php echo $atencion['id'];?>" onClick="mostrarModal('medicoModal<?php echo $atencion['id'];?>', 1)"><?php echo $atencion['nombre_solicitante']; ?> </a></td>
			<td><?php echo getEspecialidad($atencion['especialidad_id'], $db); ?> </td>
			<td><?php echo getComuna($atencion['comuna_id'], $db); ?> </td>
			<td><?php echo $atencion['email']; ?> 
				<br>Twitter:<?php echo $atencion['twitter']; ?> 
				<br>Fono:<?php echo $atencion['celular']; ?> </td>
		</tr>
<?php if(count($atenciones)-1==(5*$pagina+$i)){
	$stop=-1;
}}
	else{
		$stop=-1;
	}
} 
$db->close();?>

</table>

<?php 
$db = DbConfig::getConnection();
for ($i = 0; $i <5; $i++){
	if(count($atenciones)>(5*$pagina+$i)){
		$atencion=$atenciones[5*$pagina+$i];?>
		<div id="medicoModal<?php echo $atencion['id'];?>" class="modal">
			<div class="modal-contenido">
				<span onClick="mostrarModal('medicoModal<?php echo $atencion['id'];?>', 0)" class="close">Cerrar</span>
				<h2><?php echo $atencion['nombre_solicitante']; ?></h2>
				<p><b>Región de atención:</b><?php echo getRegion($atencion['comuna_id'], $db); ?></p>
				<p><b>Comuna de atención</b><?php echo getComuna($atencion['comuna_id'], $db); ?></p>
				<p><b>Síntomas:</b><?php echo $atencion['sintomas']; ?></p>
				<p><b>Especialidades:</b><?php echo getEspecialidad($atencion['especialidad_id'], $db); ?></p>
				<p><b>Twitter:</b><?php echo $atencion['twitter']; ?></p>
				<p><b>Email:</b><?php echo $atencion['email']; ?></p>
				<p><b>Celular:</b><?php echo $atencion['celular']; ?></p>
				<?php 
				$docs = getDocsAtencion($db, $atencion['id']);
				foreach ($docs as $doc) { ?>
					<p> <a href="<?php echo substr($doc['ruta_archivo'], 3); ?>" >Descargar <?php echo $doc['nombre_archivo']; ?>. </a>  Archivo del tipo <?php echo $doc['mimetype']; ?> </p> <br>
				<?php }?>
			</div>  
		</div>
	<?php }
} 
$db->close();?>




<?php if($pagina>0){?>
<a type="button" id="previous_page" style="width: 18%; padding: 3px 20px; margin: 5px 0;" href="hours.php?pagina=<?php echo $pagina-1 ?>">Página anterior</a> <br> <?php } ?>
<?php if($stop==0){?>
<a type="button" id="next_page" style="width: 18%; padding: 3px 20px; margin: 5px 0;" href="hours.php?pagina=<?php echo $pagina+1 ?>">Siguiente página</a> <?php } ?>




<script> 
	function mostrarModal(modalId, onOff){
		if(onOff==1){
			document.getElementById(modalId).style.display = 'block';
		} 
		else{
			document.getElementById(modalId).style.display = 'none';
		}
	}
</script>
</body>
</html>

