 /**
  * Válidator generalizado. 
  * id: id del input a validar.
  * type: typo de validación. Posibilidades a la fecha: len, text, phone, email, twitter, check, select.
  * minLen: largo mínimo del input. Valor por defecto=1.
  * maxLen: largo máximo del input. Valor por defecto=0 (infinito)
  */

function validate(id, type, minLen=1, maxLen=0){
	var DEBUG=0;
	var toValidate=document.getElementById(id);
	if (DEBUG) console.log(toValidate);
	var parent=document.getElementById("div"+id);
	if (DEBUG) console.log(parent);
	
	if (parent.getElementsByTagName("p").length>0){
		var perror=parent.getElementsByTagName("p");
		if (DEBUG) console.log(perror);
		perror[0].parentNode.removeChild(perror[0]);
	}
	
	var val=toValidate.value;
	var htmlError= '<p class="error">';
	switch (type) {
		case "len":
			if (DEBUG) console.log("len");
			if(val.length<minLen || (maxLen>0 && val.length>maxLen)){
				toValidate.insertAdjacentHTML("afterend", htmlError+"Error en la extensión del campo.</p>");
			}
			break;
			
		case "text":
			if (DEBUG) console.log("text");
			var regex = new RegExp("^[a-zA-Z]*$");
			if(!regex.test(val)){
				toValidate.insertAdjacentHTML("afterend", htmlError+"El campo sólo debe contener letras.</p>");
			}
			else if(val.length<minLen || (maxLen>0 && val.length>maxLen)){
				toValidate.insertAdjacentHTML("afterend", htmlError+"Error en la extensión del campo.</p>");
			}
			break;
			
		case "phone":
			if (DEBUG) console.log("phone");
			var regex = new RegExp("^[0-9]{9}$");
			if (minLen==0){
				regex = new RegExp("^([0-9]{9})?$");
			}
			if(!regex.test(val)){
				toValidate.insertAdjacentHTML("afterend", htmlError+"Por favor ingrese un número con el formato correcto de nueve dígitos.</p>");
			}
			break;
			
		case "email":
			if (DEBUG) console.log("email");
			var regex = new RegExp("^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$");
			if (minLen==0){
				regex = new RegExp("^([a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)?$");
			}
			if(!regex.test(val)){
				toValidate.insertAdjacentHTML("afterend", htmlError+"Por favor ingrese un mail válido.</p>");
			}
			break;
			
		case "twitter":
			if (DEBUG) console.log(count);
			var regex = new RegExp("^@?[a-zA-Z0-9_]{1,15}$");
			if (minLen==0){
				regex = new RegExp("^(@?[a-zA-Z0-9_]{1,15})?$");
			}
			if(!regex.test(val)){
				toValidate.insertAdjacentHTML("afterend", htmlError+"Por favor ingrese una cuenta de twitter válida.</p>");
			}
			break;
			
		case "check":
			if (DEBUG) console.log("checks:");
			var checks=document.getElementsByName(id+"[]");
			if (DEBUG) console.log(checks);
			var count=0;
			for(var i = 0; i < checks.length; i++){
				if (DEBUG) console.log(checks[i]);
			   if ($(checks[i]).prop("checked")){
					count++;
				}
			};
			if (DEBUG) console.log(count);
			if(count<minLen || (maxLen>0 && count>maxLen)){
				toValidate.insertAdjacentHTML("afterend", htmlError+"Está seleccionando una cantidad incorrecta de opciones. </p>");
			}
			break;
			
		case "select":
			if (DEBUG) console.log("select");
			if(val==''){
			toValidate.insertAdjacentHTML("afterend", htmlError+"No se ha seleccionado ni una opción.</p>");
			}
			break;
			
		case "file":
			//falta validar archivossssssssssssssssssss
			break;
		}
	isOk();
}

 /**
  * Habilita botón submit si no existen errores
  */
function isOk(){
	var DEBUG=0;
	if (DEBUG) console.log("isOk()");
	var formsArray=document.getElementsByTagName("form");
	
	if (DEBUG) console.log(formsArray[0]);
	var form1= formsArray[0];
	var perror= form1.getElementsByTagName("p");
	var submitButton= document.getElementById("submit-"+form1.id);
	
	if (DEBUG) console.log(perror);
	if (perror.length==0){
		if (DEBUG) console.log("is OK");
		if (DEBUG) console.log(submitButton);
		//submitButton.removeAttribute("disabled");
		var inputs= form1.getElementsByTagName("input");
		var count=0;
		for(var i = 0; i < inputs.length; i++){
			//if (DEBUG) console.log(inputs[i]);
			if (DEBUG) console.log($(inputs[i]).prop("required"));
			if (DEBUG) console.log($(inputs[i]).prop("value"));
			
			if ($(inputs[i]).prop("required") && $(inputs[i]).prop("value")==''){
				if (DEBUG) console.log("required && value==''");
				count++;
			}
		};
		if (count==0){
			submitButton.removeAttribute("disabled");
		}
	}
	else {
		submitButton.setAttribute("disabled",true);
	}
} 