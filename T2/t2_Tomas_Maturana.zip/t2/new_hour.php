<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="static/style.css">
    <title>Solicitar atención</title>
	<script src="static/jquery-3.5.0.js" ></script>
	<!-- Validator -->
	<script src="static/validator.js"></script>
	<!-- /Validator -->
	<!-- Fotos -->
	<script src="static/fileCharger.js"></script>
	<!-- /Fotos -->
	<!-- relleno región y comuna -->
	<script src="static/regionesYComunas.js"></script>
	<!-- /relleno región y comuna -->
</head>
<body>
<ul class="navbar">
  <li><a href="index.php">Página principal</a>
  <li><a href="new_med.php">Agregar médico</a>
  <li><a href="meds.php">Ver médicos</a>
  <li><a href="new_hour.php">Publicar atención</a>
  <li><a href="hours.php">Ver atenciones</a>
</ul>

<h1>Solicitar atención:</h1>
<p> Los campos marcados con * son obligatorios</p>

<div class="avisos">
  <?php
    if(isset($_GET['errores'])){
      echo $_GET['errores']; 
    }
  ?>
</div>

<div>
  <form method="post" id="form1" action="modelcontroller/agregar_atencion.php" enctype="multipart/form-data">
    <br>
	
	<div id="divnombre-solicitante">	
		<label for="nombre-solicitante" class="text-field">Nombre de solicitante*</label>
		<br>
		<input type="text" id="nombre-solicitante" name="nombre-solicitante" size="30" placeholder="Nombre de solicitante" required onchange="validate('nombre-solicitante', 'text',1,30)">
    </div>
	
	<div id="divespecialidad-solicitante" >	
		<label class="text-field">Especialidad*</label>
		<div class="parent" id="especialidad-solicitante" onchange="validate('especialidad-solicitante', 'check',1,1)">
			<div class="child">	
				<input type="checkbox" name="especialidad-solicitante[]" value="1">Cardiología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="2">Gastroenterología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="3">Endocrinología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="4">Epidemiología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="25">Geriatría
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="5">Hematología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="6">Infectología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="7">Medicina del deporte
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="8">Medicina de urgencias
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="9">Medicina interna
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="10">Nefrología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="11">Neumología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="12">Neurología
			</div>
			<div class="child">
				<input type="checkbox" name="especialidad-solicitante[]" value="13">Nutriología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="14">Oncología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="15">Pediatría
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="16">Psiquiatría
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="17">Reumatología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="18">Toxicología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="19">Dermatología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="20">Ginecología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="21">Oftalmología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="22">Otorrinolaringología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="23">Urología
				<br>
				<input type="checkbox" name="especialidad-solicitante[]" value="24">Traumatología
				<br>
			</div>
		</div>
	</div>
	
	<div id="divsintomas-solicitante">	
		<label for="sintomas-solicitante" class="text-field">Síntomas</label>
		<br>
		<textarea id="sintomas-solicitante" name="sintomas-solicitante" maxlength="500" cols="40" rows="8" placeholder="Síntomas" onchange="validate('sintomas-solicitante', 'len', 1, 500)"></textarea>
    </div>
	
	<div id="divarchivos-solicitante">
		<div id="archivos-solicitante" onchange="validate('archivos-solicitante', 'file')">
			<a class="text-field">Archivos complementarios</a>
			<br>
			<div id="photo1">
				<input type="hidden" name="MAX_FILE_SIZE" value="3000000" />
				<input type="file"  name="archivos-solicitante[]" accept="image/*, video/*">
				<br>
			</div>
			<button type="button" id="new_photo_button" style="width: 18%; padding: 3px 20px; margin: 5px 0;" onclick="new_file('archivos-solicitante', 5, 'image/*, video/*', 'new_photo_button')">Subir otra</button>
			<br>
		</div>
	</div>
	
	<div id="divtwitter-solicitante">	
		<label for="twitter-solicitante" class="text-field">Twitter solicitante</label>
		<br>
		<input type="text" id="twitter-solicitante" name="twitter-solicitante" size="30" placeholder="Twitter solicitante" onchange="validate('twitter-solicitante', 'twitter',0)">
    </div>
	
	<div id="divemail-solicitante">
		<label for="email-solicitante" class="text-field">Email solicitante</label>
		<br>
		<input type="text" id="email-solicitante" name="email-solicitante" size="30" placeholder="Email solicitante" onchange="validate('email-solicitante', 'email',0)">
    </div>
	
	<div id="divcelular-solicitante">	
		<label for="celular-solicitante" class="text-field">Número celular solicitante</label>
		<br>
		<input type="text" id="celular-solicitante" name="celular-solicitante" pattern="[0-9]{9}" placeholder="9 9999 9999" onchange="validate('celular-solicitante', 'phone',0)">
    </div>
	
		<div id="divregion-solicitante">
		<label for="region-solicitante" class="text-field">Región*</label>
		<br>
		<select id="region-solicitante" name="region-solicitante" required onchange="validate('region-solicitante', 'select')"> 
			<option value="">Seleccione región</option>
		</select>
		
    </div>
	
	<div id="divcomuna-solicitante">
		<label for="comuna-solicitante" class="text-field">Comuna*</label>
		<br>
		<select id="comuna-solicitante" name="comuna-solicitante" required onchange="validate('comuna-solicitante', 'select')">
			<option value="">Seleccione comuna</option>
		</select>
    </div>
	
	<div>	
		<input type="submit" id="submit-form1" disabled value="Agregar">
		<br>
		<button type="reset" >Limpiar</button>
	</div>
	
	
  </form>
</div>

<script> $(document).ready(regiones('region-solicitante','comuna-solicitante')); </script>
</body>

</html>



