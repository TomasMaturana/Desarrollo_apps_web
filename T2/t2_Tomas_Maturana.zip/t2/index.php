<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="static/style.css">
    <title>Title</title>
</head>

<body>
<ul class="navbar">
  <li><a href="index.php">Página principal</a>
  <li><a href="new_med.php">Agregar médico</a>
  <li><a href="meds.php">Ver médicos</a>
  <li><a href="new_hour.php">Publicar atención</a>
  <li><a href="hours.php">Ver atenciones</a>
</ul>


<div class="avisos">
  <?php
    if(isset($_GET['avisos'])){
      echo $_GET['avisos']; 
    }
  ?>
</div>

<h1>Página principal</h1>

<!-- Firma y fecha -->
<address> 
	Tomás Maturana <br> 
	Otoño 2020 <br> 
	T1 Desarrollo de Aplicaciones Web
</address>

</body>
</html>

