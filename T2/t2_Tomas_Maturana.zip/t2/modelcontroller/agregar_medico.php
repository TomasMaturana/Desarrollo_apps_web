<?php
require_once("validaciones_medico.php");
require_once('db_config.php');
require_once('consultas.php');

$errores = array();
if(!checkRegion($_POST)){
	$errores[] = "Seleccione región.";
}
if(!checkComuna($_POST)){
	$errores[] = "Seleccione comuna.";
}
if(!checkNombre($_POST)){
	$errores[] = "Ingrese un nombre válido.";
}
if(!checkExperiencia($_POST)){
	$errores[] = "Ingrese la experiencia del médico en menos de quinientos caracteres.";
}
if(!checkEspecialidad($_POST)){
	$errores[] = "Seleccione al menos una especialidad y máximo cinco.";
}
if(!checkTwitter($_POST)){
	$errores[] = "Ingrese una cuenta de Twitter válida.";
}
if(!checkEmail($_POST)){
	$errores[] = "Ingrese un email válido.";
}
if(!checkTelefono($_POST)){
	$errores[] = "Ingrese un número de teléfono válido de nueve dígitos. (Ejemplo: 999999999)";
}
if(count($errores)>0){//Si el arreglo $errores tiene elementos, debemos mostrar el error.
	header("Location: ../new_med.php?errores=".implode($errores, "<br>"));//Redirigimos al formulario inicio con los errores encontrados
	return; //No dejamos que continue la ejecución
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$target_dir = "../media/photos/";
$files[] =array();
foreach ($_FILES["foto-medico"]["error"] as $key => $error) {
	if ($error == UPLOAD_ERR_OK) {
		$tmp_name = $_FILES["foto-medico"]["tmp_name"][$key];
		$file_name = basename($_FILES["foto-medico"]["name"][$key]);
		$target_file = $target_dir . basename($_FILES["foto-medico"]["name"][$key]);
		$files[] = array("file" => $target_file, "name" => $file_name);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		
		// Check if image file is a actual image or fake image
		if(isset($_POST["submit"])) {
			$check = getimagesize($_FILES["foto-medico"]["tmp_name"][$key]);
			if($check == false) {
				$errores[] = "El archivo subido no es una imagen.";
				$uploadOk = 0;
			}
		}
		// Check if file already exists
		if (file_exists($target_file)) {
			$uploadOk = 0;
		}
		// Check file size
		if ($_FILES["foto-medico"]["size"][$key] > 3000000) {
			$errores[] = "El archivo subido es demasiado grande.";
			$uploadOk = 0;
		}
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			$errores[] = "Sólo se permiten archivos JPG, JPEG, PNG o GIF.";
			$uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
		// if everything is ok, try to upload file
		} else {
			if (move_uploaded_file($_FILES["foto-medico"]["tmp_name"][$key], $target_file)) {
				echo "The file ". basename( $_FILES["foto-medico"]["name"][$key]). " has been uploaded.";
			} else {
				$errores[] = "Hubo un error intentando subir su archivo, por favor inténtelo nuevamente.";
			}
		}
	}
	else {
		$errores[] = "Hubo un error intentando subir su archivo, por favor inténtelo nuevamente.";
	}
}

//validated
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
if(count($errores)>0){//Si el arreglo $errores tiene elementos, debemos mostrar el error.
	header("Location: ../new_med.php?errores=".implode($errores, "<br>"));//Redirigimos al formulario inicio con los errores encontrados
	return; //No dejamos que continue la ejecución
}

//Guardamos en base de datos
$db = DbConfig::getConnection();
$idComuna = getIdComuna($_POST['comuna-medico'], $db);

$res = guardarMedico($db, $idComuna['id'], $_POST['nombre-medico'], $_POST['experiencia-medico'], $_POST['especialidades-medico'], $_POST['twitter-medico'], $_POST['email-medico'], $_POST['celular-medico'], $files);

$db->close();

$guardado_exitoso = array();

if($res){
	$guardado_exitoso[]="La información del médico se ha guardado satisfactoriamente.";
	header("Location: ../index.php?avisos=".implode($guardado_exitoso, "<br>"));
	return;
}
?>
