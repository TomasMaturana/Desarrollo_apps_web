<?php
/**
 * Validación nombre con PHP.
 */

function checkRegion($post){
	if(isset($post['region-medico'])){
		return true;
	}
	return false;
}

function checkComuna($post){
	if(isset($post['comuna-medico'])){
		return true;
	}
	return false;
}

function checkNombre($post){
	if(isset($post['nombre-medico'])){
		$regexp = "/^[A-Za-záéíóú\ ]+$/";
		if(preg_match($regexp, $post['nombre-medico']) && strlen($post['nombre-medico'])<= 30){
			return true;
		}
	}
	return false;
}

function checkExperiencia($post){
	if(isset($post['experiencia-medico'])){
		$regexp = "/^[A-Za-záéíóú\ ]+|$/";
		if(preg_match($regexp, $post['experiencia-medico']) && strlen($post['experiencia-medico'])<= 500){
			return true;
		}
	}
	else {
		return true;
	}
	return false;
}

function checkEspecialidad($post){
	if(isset($post['especialidades-medico']) && count($post['especialidades-medico']) > 0 && count($post['especialidades-medico']) < 6){
		return true;
	}
	return false;
}

function checkTwitter($post){
	if(isset($post['twitter-medico'])){
		$regexp = "/^@?[a-zA-Z0-9_]{1,15}|$/";
		if(preg_match($regexp, $post['twitter-medico'])){
			return true;
		}
	}
	return false;
}

function checkEmail($post){
	if(isset($post['email-medico'])){
		$regexp = "/^[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/";
		if(preg_match($regexp, $post['email-medico'])){
			return true;
		}
	}
	return false;
}

function checkTelefono($post){
	if(isset($post['celular-medico'])){
		$regexp = "/^[0-9]{9}|$/";
		if(preg_match($regexp, $post['celular-medico'])){
			return true;
		}
	}
	return false;
}
?>