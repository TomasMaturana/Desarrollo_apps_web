<?php
require_once("validaciones_atencion.php");
require_once('db_config.php');
require_once('consultas.php');

$errores = array();
if(!checkRegion($_POST)){
	$errores[] = "Seleccione región.";
}
if(!checkComuna($_POST)){
	$errores[] = "Seleccione comuna.";
}
if(!checkNombre($_POST)){
	$errores[] = "Ingrese un nombre válido.";
}
if(!checkSintomas($_POST)){
	$errores[] = "Ingrese los síntomas en menos de quinientos caracteres.";
}
if(!checkEspecialidad($_POST)){
	$errores[] = "Seleccione una especialidad.";
}
if(!checkTwitter($_POST)){
	$errores[] = "Ingrese una cuenta de Twitter válida.";
}
if(!checkEmail($_POST)){
	$errores[] = "Ingrese un email válido.";
}
if(!checkTelefono($_POST)){
	$errores[] = "Ingrese un número de teléfono válido de nueve dígitos. (Ejemplo: 999999999)";
}
if(count($errores)>0){//Si el arreglo $errores tiene elementos, debemos mostrar el error.
	header("Location: ../new_hour.php?errores=".implode($errores, "<br>"));//Redirigimos al formulario inicio con los errores encontrados
	return; //No dejamos que continue la ejecución
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$target_dir = "../media/docs/";
$files[] =array();
foreach ($_FILES["archivos-solicitante"]["error"] as $key => $error) {
	if ($error == UPLOAD_ERR_OK) {
		$tmp_name = $_FILES["archivos-solicitante"]["tmp_name"][$key];
		$file_name = basename($_FILES["archivos-solicitante"]["name"][$key]);
		$target_file = $target_dir . basename($_FILES["archivos-solicitante"]["name"][$key]);
		$uploadOk = 1;
		$docFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		
		// Check if image file is a actual image or fake image
		if(isset($_POST["submit"])) {
			$check = getimagesize($_FILES["archivos-solicitante"]["tmp_name"][$key]);
			if($check == false) {
				$errores[] = "El archivo subido no es una imagen ni un video.";
				$uploadOk = 0;
			}
		}
		// Check if file already exists
		if (file_exists($target_file)) {
			$uploadOk = 0;
		}
		// Check file size
		if ($_FILES["archivos-solicitante"]["size"][$key] > 3000000) {
			$errores[] = "El archivo subido es demasiado grande.";
			$uploadOk = 0;
		}
		// Allow certain file formats
		if($docFileType != "jpg" && $docFileType != "png" && $docFileType != "jpeg"
		&& $docFileType != "gif" ) {
			$errores[] = "Sólo se permiten archivos JPG, JPEG, PNG o GIF.";
			$uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
		// if everything is ok, try to upload file
		} else {
			if (move_uploaded_file($_FILES["archivos-solicitante"]["tmp_name"][$key], $target_file)) {
				$mimetype = mime_content_type($target_file);
				$files[] = array("file" => $target_file, "name" => $file_name, "mimetype" => $mimetype);
				echo "The file ". basename( $_FILES["archivos-solicitante"]["name"][$key]). " has been uploaded.";
			} else {
				$errores[] = "Hubo un error intentando subir su archivo, por favor inténtelo nuevamente.";
			}
		}
	}
	else {
		$errores[] = "Hubo un error intentando subir su archivo, por favor inténtelo nuevamente.";
	}
}

//validated
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
if(count($errores)>0){//Si el arreglo $errores tiene elementos, debemos mostrar el error.
	header("Location: ../new_hour.php?errores=".implode($errores, "<br>"));//Redirigimos al formulario inicio con los errores encontrados
	return; //No dejamos que continue la ejecución
}

//Guardamos en base de datos
$db = DbConfig::getConnection();
$idComuna = getIdComuna($_POST['comuna-solicitante'], $db);
$res = guardarAtencion($db, $idComuna['id'], $_POST['nombre-solicitante'], $_POST['sintomas-solicitante'], $_POST['especialidad-solicitante'], $_POST['twitter-solicitante'], $_POST['email-solicitante'], $_POST['celular-solicitante'], $files);

$db->close();

$guardado_exitoso = array();

if($res){
	$guardado_exitoso[]="La información de la atención se ha guardado satisfactoriamente.";
	header("Location: ../index.php?avisos=".implode($guardado_exitoso, "<br>"));
	return;
}
?>
