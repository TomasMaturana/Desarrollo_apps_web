<?php
require_once('modelcontroller/db_config.php');
require_once('modelcontroller/consultas.php');
$db = DbConfig::getConnection();
$medicos = getMedicos($db);
$db->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="static/style.css">
    <title>Médicos</title>
</head>
<body>
<ul class="navbar">
  <li><a href="index.php">Página principal</a>
  <li><a href="new_med.php">Agregar médico</a>
  <li><a href="meds.php">Ver médicos</a>
  <li><a href="new_hour.php">Publicar atención</a>
  <li><a href="hours.php">Ver atenciones</a>
</ul>

<h1>Médicos disponibles</h1>
<p> </p>

<?php 
$stop=0;
if(isset($_GET['pagina'])){
	if(($_GET['pagina']>=0) && ($_GET['pagina']<(count($medicos)/5) )){
		$pagina=$_GET['pagina']; 
	}
	else{
		$pagina=0;
	}
}
else{
	$pagina=0;
}?>


<table>
	<tr>
	<th>Nombre médico</th>
	<th>Especialidades</th>
	<th>Comuna</th>
	<th>Datos contacto</th>
	</tr>

	<?php 
	$db = DbConfig::getConnection();
	for ($i = 0; $i <5; $i++){
		if(count($medicos)>(5*$pagina+$i)){
			$medico=$medicos[5*$pagina+$i];
			$especialidades=getEspecialidadMed($db, $medico['id']);?>
			<tr onClick="mostrarModal('medicoModal<?php echo $medico['id'];?>', 1)">
				<td><a href="#medicoModal<?php echo $medico['id'];?>" onClick="mostrarModal('medicoModal<?php echo $medico['id'];?>', 1)"><?php echo $medico['nombre']; ?> </a></td>
				<td><?php foreach ($especialidades as $especialidad) { 
					echo getEspecialidad($especialidad['especialidad_id'], $db); ?> <br> <?php 
				}?> </td>
				<td><?php echo getComuna($medico['comuna_id'], $db); ?> </td>
				<td><?php echo $medico['email']; ?> 
					<br>Twitter:<?php echo $medico['twitter']; ?> 
					<br>Fono:<?php echo $medico['celular']; ?> </td>
			</tr>
	<?php if(count($medicos)-1==(5*$pagina+$i)){
		$stop=-1;
	}}
		else{
			$stop=-1;
		}
	} 
	$db->close();?>
</table>


<?php 
$db = DbConfig::getConnection();
for ($i = 0; $i <5; $i++){
	if(count($medicos)>(5*$pagina+$i)){
		$medico=$medicos[5*$pagina+$i];
		$especialidades=getEspecialidadMed($db, $medico['id']);?>
		<div id="medicoModal<?php echo $medico['id'];?>" class="modal">
			<div class="modal-contenido">
				<span onClick="mostrarModal('medicoModal<?php echo $medico['id'];?>', 0)" class="close">Cerrar</span>
				<h2><?php echo $medico['nombre']; ?></h2>
				<p><b>Región de atención:</b><?php echo getRegion($medico['comuna_id'], $db); ?></p>
				<p><b>Comuna de atención</b><?php echo getComuna($medico['comuna_id'], $db); ?></p>
				<p><b>Experiencia:</b><?php echo $medico['experiencia']; ?></p>
				<p><b>Especialidades:</b><?php foreach ($especialidades as $especialidad) { 
					echo getEspecialidad($especialidad['especialidad_id'], $db); ?> <br> <?php 
				}?></p>
				<p><b>Twitter:</b><?php echo $medico['twitter']; ?></p>
				<p><b>Email:</b><?php echo $medico['email']; ?></p>
				<p><b>Celular:</b><?php echo $medico['celular']; ?></p>
				<?php 
				$fotos = getFotosMed($db, $medico['id']);
				foreach ($fotos as $foto) { ?>
					<img src="<?php echo substr($foto['ruta_archivo'], 3); ?>" alt="<?php echo $medico['nombre']; ?>" height="320" width="240" onClick="this.style.height = '600px'; this.style.width = '800px';">  
				<?php }?>
			</div>  
		</div>
	<?php 
	}
} 
$db->close();?>





<?php if($pagina>0){?>
<a type="button" id="next_page" style="width: 18%; padding: 3px 20px; margin: 5px 0;" href="meds.php?pagina=<?php echo $pagina-1 ?>">Página anterior</a> <br> <?php } ?>
<?php if($stop==0){?>
<a type="button" id="next_page" style="width: 18%; padding: 3px 20px; margin: 5px 0;" href="meds.php?pagina=<?php echo $pagina+1 ?>">Siguiente página</a> <?php } ?>


<script> 
	function mostrarModal(modalId, onOff){
		if(onOff==1){
			document.getElementById(modalId).style.display = 'block';
		} 
		else{
			document.getElementById(modalId).style.display = 'none';
		}
	}
</script>


</body>
</html>

