<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
	<h1>Detalles para orden <?php echo $_GET['orden_id'] ?></h1>
	<h3>En construcción...</h3>
</body>
</html>