El proyecto fue probado en Eclipse con Tomcat v6, siguiendo la guía recomendada en el foro: 
https://medium.com/@fernandochristyanto/create-and-run-java-servlet-web-app-2-5-using-eclipse-and-apache-tomcat-87c546fa0aa5
