package com.ej6.model;

public enum LiquorType {
	WINE, BEER, WHISKY
}
