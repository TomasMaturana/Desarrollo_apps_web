package com.ej6.model;

import java.util.ArrayList;
import java.util.List;

import com.ej6.model.LiquorType;

public class LiquorService {
	
public static List<String> getAvailableBrands(LiquorType type) {
		
		List<String> brands = new ArrayList();
		
		if (type.equals(LiquorType.WINE)) {
			brands.add("Adrianna Vineyard");
			brands.add("J. P. Chenet");
		}
		else if (type.equals(LiquorType.WHISKY)) {
			brands.add("Glenfiddich");
			brands.add("Johnnie Walker");
		} 
		else if (type.equals(LiquorType.BEER)) {
			brands.add("Corona");
		} else {
			brands.add("No Brand Available");
		}
		return brands;
	}

}
