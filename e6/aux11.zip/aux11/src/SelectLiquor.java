

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ej6.model.LiquorService;
import com.ej6.model.LiquorType;

/**
 * Servlet implementation class SelectLiquor
 */
public class SelectLiquor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectLiquor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tipo= request.getParameter("Type");
		LiquorType licor;
		licor=LiquorType.valueOf(tipo);
		List<String> lista= LiquorService.getAvailableBrands(licor);
		request.setAttribute("res",lista);
		request.getRequestDispatcher("mostrar.jsp").forward(request, response);
	}

}
